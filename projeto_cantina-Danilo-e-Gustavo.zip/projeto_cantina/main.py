import sys
import sqlite3
from datetime import datetime
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QLineEdit, QListWidget, QListWidgetItem,
    QMessageBox, QStackedWidget, QGridLayout, QScrollArea,
    QFrame, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView,
    QComboBox, QInputDialog
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QColor

DB_NAME = "pedidos.db"

CARDAPIO = {
    "Doces": {
        "Paçoca": 1.00,
        "Bom Bom - Sonho de Valsa": 2.50,
        "Bom Bom - Ouro Branco": 2.50,
        "Emilia": 2.50,
        "Halls - Extra Forte (Preto)": 2.50,
        "Halls - Morango": 2.50,
        "Halls - Menta": 2.50,
        "Halls - Melancia": 2.50,
        "Trident - Morango": 2.50,
        "Trident - Tutti-Fruit": 2.50,
        "Trident - Menta": 2.50,
        "Trident - Canela": 2.50,
        "Cremosinho - Morango": 2.50,
        "Cremosinho - Maracujá": 2.50,
        "Cremosinho - Leite Condensado": 2.50,
        "Cremosinho - Coco": 2.50,
        "Cremosinho - Uva": 2.50,
        "Cremosinho - Kiwi": 2.50,
        "Cremosinho - Açaí com Banana": 2.50,
        "Cremosinho - Frutas Tropicais": 2.50,
        "Cremosinho - Frutas Cristalizadas": 2.50,
        "Cremosinho - Manga": 2.50,
        "Doce": 3.00,
        "Doce em Massa de Batata Doce": 3.00,
        "Cajuzinho": 3.00,
        "Maria Bolacha": 3.00,
        "Copinho de Banana": 3.00,
        "Cocada": 3.00,
        "Suspiro": 3.00,
        "Biscoito - Chocolate": 3.50,
        "Biscoito - Morango": 3.50,
        "Chokito": 4.00,
        "Trento - Mousse de Maracujá": 4.50,
        "Trento - Torta de Limão": 4.50,
        "Trento - Dark": 4.50,
        "Trento - Chocolate": 4.50,
        "Pão de Mel": 5.00,
        "Bolo": 6.00,
        "Geladão - Leite Condensado": 7.00,
        "Geladão - Morango": 7.00,
        "Geladão - Maracujá": 7.00,
        "Geladão - Leite em Pó": 7.00,
        "Geladão - Paçoca": 7.00,
    },
    "Salgados": {
        "Pão de Queijo": 3.50,
        "Risole de 4 Queijos": 5.50,
        "Risole de Carne": 5.50,
        "Coxinha": 5.50,
        "Croissant 3 Queijos": 6.50,
        "Pão de Batata com Calabresa": 6.50,
        "Pão de Batata de Frango": 6.50,
        "Croissant Apresentado e Queijo": 7.00,
        "Hambúrguer com Cheddar": 7.00,
        "Enroladinho de Bauru": 7.00,
        "Esfiha de Carne": 7.00,
        "Cup Noodles - Cheddar": 7.00,
        "Cup Noodles - Galinha Caipira": 7.00,
        "Cup Noodles - Queijo": 7.00,
        "Cup Noodles - Bolonhesa": 7.00,
        "Espeto - Carne": 9.00,
        "Espeto - Medalhão": 9.00,
        "Espeto - Coração": 9.00,
        "Prato Feito - Strogonoff de Carne": 20.00,
        "Prato Feito - Strogonoff de Frango": 20.00,
        "Prato Feito - Bife": 20.00,
        "Prato Feito - Filé de Frango": 20.00,
        "Prato Feito - Churrasco": 20.00,
        "Caldo - Mandioca": 20.00,
        "Caldo - Abóbora": 20.00,
        "Caldo - Verde": 20.00,
        "Caldo - Feijão": 20.00,
    },
    "Bebidas": {
        "Café": 2.00,
        "Refrigerante Caçula 200ml": 4.00,
        "Guaraná 350ml": 5.50,
        "Fanta Uva 350ml": 5.50,
        "Fanta Laranja 350ml": 5.50,
        "Coca-Cola Zero 350ml": 5.50,
        "Coca-Cola 350ml": 5.50,
        "Suco Kmais - Goiaba": 7.50,
        "Suco Kmais - Laranja": 7.50,
        "Suco Kmais - Uva": 7.50,
        "Suco Kmais - Maracujá": 7.50,
        "Suco Tropical - Uva": 8.00,
        "Suco Tropical - Manga": 8.00,
        "Suco Tropical - Abacaxi": 8.00,
        "Suco Tropical - Açaí": 8.00,
        "Suco Tropical - Goiaba": 8.00,
    }
}

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero INTEGER,
            nome_cliente TEXT,
            itens TEXT,
            total REAL,
            status TEXT DEFAULT 'Pendente',
            data TEXT
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS estoque (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT UNIQUE,
            categoria TEXT,
            preco REAL,
            quantidade INTEGER DEFAULT 0,
            minimo INTEGER DEFAULT 5
        )
    """)

    c.execute("SELECT COUNT(*) FROM estoque")
    if c.fetchone()[0] == 0:
        for categoria, itens in CARDAPIO.items():
            for nome, preco in itens.items():
                c.execute("""
                    INSERT INTO estoque (nome, categoria, preco, quantidade, minimo)
                    VALUES (?, ?, ?, 0, 5)
                """, (nome, categoria, preco))
    else:
        for categoria, itens in CARDAPIO.items():
            for nome, preco in itens.items():
                c.execute("SELECT 1 FROM estoque WHERE nome=?", (nome,))
                if not c.fetchone():
                    c.execute("""
                        INSERT INTO estoque (nome, categoria, preco, quantidade, minimo)
                        VALUES (?, ?, ?, 0, 5)
                    """, (nome, categoria, preco))

    conn.commit()
    conn.close()

def proximo_numero():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT MAX(numero) FROM pedidos")
    r = c.fetchone()[0]
    conn.close()
    return (r or 0) + 1

def salvar_pedido(nome, itens, total):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    numero = proximo_numero()
    c.execute("""
        INSERT INTO pedidos (numero, nome_cliente, itens, total, status, data)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (numero, nome, itens, total, "PENDENTE",
          datetime.now().strftime("%d/%m/%Y %H:%M")))
    conn.commit()
    conn.close()
    return numero

def listar_pedidos():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT id, numero, nome_cliente, itens, total, status, data "
              "FROM pedidos ORDER BY numero DESC")
    dados = c.fetchall()
    conn.close()
    return dados

def atualizar_status(pedido_id, novo_status):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("UPDATE pedidos SET status=? WHERE id=?", (novo_status, pedido_id))
    conn.commit()
    conn.close()

def listar_estoque():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT id, nome, categoria, preco, quantidade, minimo "
              "FROM estoque ORDER BY categoria, nome")
    dados = c.fetchall()
    conn.close()
    return dados

def atualizar_estoque(item_id, quantidade, minimo):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("UPDATE estoque SET quantidade=?, minimo=? WHERE id=?",
              (quantidade, minimo, item_id))
    conn.commit()
    conn.close()

def ajustar_quantidade(item_id, delta):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT quantidade FROM estoque WHERE id=?", (item_id,))
    atual = c.fetchone()[0]
    nova = max(0, atual + delta)
    c.execute("UPDATE estoque SET quantidade=? WHERE id=?", (nova, item_id))
    conn.commit()
    conn.close()
    return nova

def consultar_estoque_por_nome(nome_item):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT quantidade FROM estoque WHERE nome=?", (nome_item,))
    r = c.fetchone()
    conn.close()
    return r[0] if r else None

def dar_baixa_por_nome(nome_item, qtd=1):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT id, quantidade FROM estoque WHERE nome=?", (nome_item,))
    r = c.fetchone()
    if r:
        nova = max(0, r[1] - qtd)
        c.execute("UPDATE estoque SET quantidade=? WHERE id=?", (nova, r[0]))
    conn.commit()
    conn.close()

# ==========================================================
# JANELA 1: TOTEM (cliente)
# ==========================================================
class TotemWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TOTEM - Cantina IF (Cliente)")
        self.resize(900, 700)
        self.carrinho = []
        self.botoes_produtos = {}

        central = QWidget()
        self.setCentralWidget(central)
        central.setStyleSheet("background-color: white;")
        layout = QVBoxLayout(central)
        layout.setContentsMargins(20, 20, 20, 20)

        titulo = QLabel("CANTINA IF - TOTEM DE PEDIDOS")
        titulo.setAlignment(Qt.AlignCenter)
        titulo.setFont(QFont("Arial", 22, QFont.Bold))
        titulo.setStyleSheet("color: #1B5E20; padding: 12px;")
        layout.addWidget(titulo)

        linha_nome = QHBoxLayout()
        lbl_nome = QLabel("Seu nome:")
        lbl_nome.setStyleSheet("color: #1B5E20; font-weight: bold;")
        linha_nome.addWidget(lbl_nome)
        self.input_nome = QLineEdit()
        self.input_nome.setPlaceholderText("Digite seu nome...")
        self.input_nome.setStyleSheet(
            "padding: 8px; font-size: 14px; "
            "border: 2px solid #2E7D32; border-radius: 6px; "
            "background-color: white; color: #1B5E20;"
        )
        linha_nome.addWidget(self.input_nome)
        layout.addLayout(linha_nome)

        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane {
                border: 2px solid #2E7D32;
                border-radius: 6px;
                background-color: white;
            }
            QTabBar::tab {
                background-color: white;
                color: #1B5E20;
                padding: 10px 20px;
                font-weight: bold;
                border: 2px solid #2E7D32;
                border-bottom: none;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background-color: #2E7D32;
                color: white;
            }
            QTabBar::tab:hover {
                background-color: #A5D6A7;
            }
        """)
        for categoria, itens in CARDAPIO.items():
            self.tabs.addTab(self._criar_aba(categoria, itens), categoria)
        layout.addWidget(self.tabs)

        lbl_carrinho = QLabel("Carrinho:")
        lbl_carrinho.setStyleSheet("color: #1B5E20; font-weight: bold;")
        layout.addWidget(lbl_carrinho)
        self.lista_carrinho = QListWidget()
        self.lista_carrinho.setMaximumHeight(150)
        self.lista_carrinho.setStyleSheet("""
            QListWidget {
                background-color: white;
                border: 2px solid #2E7D32;
                border-radius: 6px;
                color: #1B5E20;
                padding: 4px;
            }
            QListWidget::item:selected {
                background-color: #A5D6A7;
                color: #1B5E20;
            }
        """)
        layout.addWidget(self.lista_carrinho)

        self.label_total = QLabel("Total: R$ 0,00")
        self.label_total.setFont(QFont("Arial", 16, QFont.Bold))
        self.label_total.setStyleSheet("color: #B71C1C; padding: 8px;")
        layout.addWidget(self.label_total)

        linha_botoes = QHBoxLayout()

        btn_remover = QPushButton("REMOVER ITEM")
        btn_remover.setStyleSheet("""
            QPushButton {
                background-color: #C62828; color: white;
                padding: 12px; font-size: 13px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #B71C1C; }
        """)
        btn_remover.clicked.connect(self.remover_item)

        btn_limpar = QPushButton("LIMPAR CARRINHO")
        btn_limpar.setStyleSheet("""
            QPushButton {
                background-color: #E53935; color: white;
                padding: 12px; font-size: 13px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #C62828; }
        """)
        btn_limpar.clicked.connect(self.limpar_carrinho)

        btn_finalizar = QPushButton("FINALIZAR PEDIDO")
        btn_finalizar.setStyleSheet("""
            QPushButton {
                background-color: #2E7D32; color: white;
                padding: 12px; font-size: 14px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #1B5E20; }
        """)
        btn_finalizar.clicked.connect(self.finalizar_pedido)

        linha_botoes.addWidget(btn_remover)
        linha_botoes.addWidget(btn_limpar)
        linha_botoes.addWidget(btn_finalizar)
        layout.addLayout(linha_botoes)

    def _criar_aba(self, categoria, itens):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background-color: white; border: none;")
        container = QWidget()
        container.setStyleSheet("background-color: white;")
        grid = QGridLayout(container)
        grid.setSpacing(10)

        for i, (nome, preco) in enumerate(itens.items()):
            btn = QPushButton(f"{nome}\nR$ {preco:.2f}")
            btn.setCheckable(True)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: white;
                    color: #1B5E20;
                    border: 2px solid #2E7D32;
                    border-radius: 8px;
                    padding: 10px;
                    font-size: 12px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #E8F5E9;
                }
                QPushButton:checked {
                    background-color: #2E7D32;
                    color: white;
                    border: 2px solid #1B5E20;
                }
                QPushButton:checked:hover {
                    background-color: #1B5E20;
                }
                QPushButton:pressed {
                    background-color: #A5D6A7;
                    color: #1B5E20;
                }
            """)
            btn.setMinimumHeight(60)
            btn.clicked.connect(lambda _, n=nome, p=preco: self.adicionar_item(n, p))
            self.botoes_produtos[nome] = btn
            grid.addWidget(btn, i // 3, i % 3)

        scroll.setWidget(container)
        return scroll

    def adicionar_item(self, nome, preco):
        self.carrinho.append((nome, preco))
        self.lista_carrinho.addItem(f"{nome} - R$ {preco:.2f}")
        self.atualizar_total()

    def remover_item(self):
        row = self.lista_carrinho.currentRow()
        if row >= 0:
            nome, _ = self.carrinho.pop(row)
            self.lista_carrinho.takeItem(row)

            # Se não houver mais nenhuma unidade desse produto no carrinho,
            # volta a deixar o botão branco.
            if not any(n == nome for n, _ in self.carrinho):
                botao = self.botoes_produtos.get(nome)
                if botao:
                    botao.setChecked(False)

            self.atualizar_total()

    def limpar_carrinho(self):
        self.carrinho.clear()
        self.lista_carrinho.clear()

        # Todos os produtos voltam ao estado branco.
        for botao in self.botoes_produtos.values():
            botao.setChecked(False)

        self.atualizar_total()

    def atualizar_total(self):
        total = sum(p for _, p in self.carrinho)
        self.label_total.setText(f"Total: R$ {total:.2f}")

    def finalizar_pedido(self):
        nome = self.input_nome.text().strip()
        if not nome:
            QMessageBox.warning(self, "Atenção", "Digite seu nome!")
            return
        if not self.carrinho:
            QMessageBox.warning(self, "Atenção", "Carrinho vazio!")
            return

        faltando = []
        for n, _ in self.carrinho:
            qtd = consultar_estoque_por_nome(n)
            if qtd is not None and qtd <= 0 and n not in faltando:
                faltando.append(n)

        if faltando:
            resp = QMessageBox.question(
                self, "Estoque insuficiente",
                "Itens sem estoque:\n• " + "\n• ".join(faltando) +
                "\n\nDeseja continuar mesmo assim?",
                QMessageBox.Yes | QMessageBox.No
            )
            if resp == QMessageBox.No:
                return

        for n, _ in self.carrinho:
            dar_baixa_por_nome(n, 1)

        itens_str = "; ".join(f"{n} (R$ {p:.2f})" for n, p in self.carrinho)
        total = sum(p for _, p in self.carrinho)
        numero = salvar_pedido(nome, itens_str, total)

        QMessageBox.information(
            self, "Pedido Confirmado",
            f"Pedido #{numero} registrado!\n"
            f"Cliente: {nome}\n"
            f"Total: R$ {total:.2f}\n\n"
            f"Aguarde ser chamado(a)."
        )
        self.input_nome.clear()
        self.limpar_carrinho()

# ==========================================================
# JANELA 2: ADMIN (Pablo)
# ==========================================================
class AdminWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ADMIN - Cantina IF (Pablo)")
        self.resize(1100, 750)

        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)
        self.stack.setStyleSheet("background-color: white;")

        self.menu = self._criar_menu()
        self.stack.addWidget(self.menu)                       # 0
        self.stack.addWidget(GestaoWindow(self.stack))        # 1
        self.stack.addWidget(FinanceiroWindow(self.stack))    # 2
        self.stack.addWidget(EstoqueWindow(self.stack))       # 3

    def _criar_menu(self):
        w = QWidget()
        w.setStyleSheet("background-color: white;")
        layout = QVBoxLayout(w)
        layout.setAlignment(Qt.AlignCenter)

        titulo = QLabel("PAINEL ADMINISTRATIVO")
        titulo.setFont(QFont("Arial", 28, QFont.Bold))
        titulo.setAlignment(Qt.AlignCenter)
        titulo.setStyleSheet("color: #B71C1C; padding: 20px;")
        layout.addWidget(titulo)

        subtitulo = QLabel("Acesso restrito — Pablo")
        subtitulo.setFont(QFont("Arial", 14, QFont.Bold))
        subtitulo.setAlignment(Qt.AlignCenter)
        subtitulo.setStyleSheet("color: #C62828; margin-bottom: 20px;")
        layout.addWidget(subtitulo)

        layout.addSpacing(20)

        def criar_btn(texto, cor, cor_hover, idx):
            b = QPushButton(texto)
            b.setMinimumSize(340, 75)
            b.setStyleSheet(f"""
                QPushButton {{
                    background-color:{cor}; color:white;
                    font-size:16px; font-weight:bold;
                    border-radius:10px; padding:15px;
                    border: none;
                }}
                QPushButton:hover {{ background-color:{cor_hover}; }}
            """)
            b.clicked.connect(lambda: self.stack.setCurrentIndex(idx))
            return b

        layout.addWidget(
            criar_btn("Gerenciar Pedidos", "#C62828", "#B71C1C", 1),
            alignment=Qt.AlignCenter
        )
        layout.addWidget(
            criar_btn("Receitas e Despesas", "#E53935", "#C62828", 2),
            alignment=Qt.AlignCenter
        )
        layout.addWidget(
            criar_btn("Controle de Estoque", "#2E7D32", "#1B5E20", 3),
            alignment=Qt.AlignCenter
        )

        return w

# ==========================================================
# TELA: GESTÃO DE PEDIDOS
# ==========================================================
class GestaoWindow(QWidget):
    def __init__(self, parent_stack):
        super().__init__()
        self.parent_stack = parent_stack
        self.setStyleSheet("background-color: white;")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        titulo = QLabel("Painel de Pedidos")
        titulo.setFont(QFont("Arial", 18, QFont.Bold))
        titulo.setStyleSheet("color: #1B5E20; padding: 10px;")
        layout.addWidget(titulo)

        self.tabela = QTableWidget()
        self.tabela.setColumnCount(6)
        self.tabela.setHorizontalHeaderLabels(
            ["#", "Cliente", "Itens", "Total", "Status", "Data"]
        )
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabela.setStyleSheet("""
            QTableWidget {
                background-color: white;
                border: 2px solid #2E7D32;
                border-radius: 6px;
                gridline-color: #C8E6C9;
                color: #1B5E20;
            }
            QHeaderView::section {
                background-color: #2E7D32;
                color: white;
                padding: 8px;
                font-weight: bold;
                border: none;
            }
            QTableWidget::item:selected {
                background-color: #A5D6A7;
                color: #1B5E20;
            }
        """)
        layout.addWidget(self.tabela)

        linha_btn = QHBoxLayout()

        btn_atualizar = QPushButton("Atualizar")
        btn_atualizar.setStyleSheet("""
            QPushButton {
                background-color: #2E7D32; color: white;
                padding: 10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #1B5E20; }
        """)
        btn_atualizar.clicked.connect(self.carregar)

        btn_pronto = QPushButton("Marcar como Pronto")
        btn_pronto.setStyleSheet("""
            QPushButton {
                background-color:#F9A825; color:white;
                padding:10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color:#F57F17; }
        """)
        btn_pronto.clicked.connect(lambda: self.alterar_status("Pronto"))

        btn_entregue = QPushButton("Marcar como Entregue")
        btn_entregue.setStyleSheet("""
            QPushButton {
                background-color:#2E7D32; color:white;
                padding:10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color:#1B5E20; }
        """)
        btn_entregue.clicked.connect(lambda: self.alterar_status("Entregue"))

        btn_voltar = QPushButton("⬅ Voltar")
        btn_voltar.setStyleSheet("""
            QPushButton {
                background-color: #C62828; color: white;
                padding: 10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #B71C1C; }
        """)
        btn_voltar.clicked.connect(lambda: self.parent_stack.setCurrentIndex(0))

        linha_btn.addWidget(btn_atualizar)
        linha_btn.addWidget(btn_pronto)
        linha_btn.addWidget(btn_entregue)
        linha_btn.addWidget(btn_voltar)
        layout.addLayout(linha_btn)

        self.carregar()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.carregar)
        self.timer.start(5000)

    def carregar(self):
        dados = listar_pedidos()
        self.tabela.setRowCount(len(dados))
        for i, row in enumerate(dados):
            for j, val in enumerate(row):
                self.tabela.setItem(i, j, QTableWidgetItem(str(val)))
        self.tabela.resizeRowsToContents()

    def alterar_status(self, novo):
        row = self.tabela.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Atenção", "Selecione um pedido!")
            return
        pedido_id = int(self.tabela.item(row, 0).text())
        atualizar_status(pedido_id, novo)
        self.carregar()

# ==========================================================
# TELA: FINANCEIRO
# ==========================================================
class FinanceiroWindow(QWidget):
    def __init__(self, parent_stack):
        super().__init__()
        self.parent_stack = parent_stack
        self.setStyleSheet("background-color: white;")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        titulo = QLabel("Receitas e Despesas")
        titulo.setFont(QFont("Arial", 18, QFont.Bold))
        titulo.setStyleSheet("color: #1B5E20; padding: 10px;")
        layout.addWidget(titulo)

        self.card_receita = self._criar_card("Receita Total", "R$ 0,00", "#2E7D32")
        self.card_pedidos = self._criar_card("Pedidos Realizados", "0", "#C62828")
        self.card_ticket = self._criar_card("Ticket Médio", "R$ 0,00", "#1B5E20")

        linha = QHBoxLayout()
        linha.addWidget(self.card_receita)
        linha.addWidget(self.card_pedidos)
        linha.addWidget(self.card_ticket)
        layout.addLayout(linha)

        btn_atualizar = QPushButton("ATUALIZAR")
        btn_atualizar.setStyleSheet("""
            QPushButton {
                background-color: #2E7D32; color: white;
                padding: 10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #1B5E20; }
        """)
        btn_atualizar.clicked.connect(self.carregar)

        btn_voltar = QPushButton("VOLTAR")
        btn_voltar.setStyleSheet("""
            QPushButton {
                background-color: #C62828; color: white;
                padding: 10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #B71C1C; }
        """)
        btn_voltar.clicked.connect(lambda: self.parent_stack.setCurrentIndex(0))

        linha_btn = QHBoxLayout()
        linha_btn.addWidget(btn_atualizar)
        linha_btn.addWidget(btn_voltar)
        layout.addLayout(linha_btn)

        self.carregar()

    def _criar_card(self, titulo, valor, cor):
        frame = QFrame()
        frame.setStyleSheet(
            f"background-color:{cor}; border-radius:10px; padding:15px;"
        )
        v = QVBoxLayout(frame)
        lbl_t = QLabel(titulo)
        lbl_t.setStyleSheet("color:white; font-size:13px; font-weight: bold;")
        lbl_v = QLabel(valor)
        lbl_v.setStyleSheet("color:white; font-size:22px; font-weight:bold;")
        v.addWidget(lbl_t)
        v.addWidget(lbl_v)
        frame.valor_label = lbl_v
        return frame

    def carregar(self):
        dados = listar_pedidos()
        total = sum(p[4] for p in dados) if dados else 0
        qtd = len(dados)
        ticket = total / qtd if qtd else 0

        self.card_receita.valor_label.setText(f"R$ {total:.2f}")
        self.card_pedidos.valor_label.setText(str(qtd))
        self.card_ticket.valor_label.setText(f"R$ {ticket:.2f}")

# ==========================================================
# TELA: ESTOQUE — agora tudo branco, seleção verde
# ==========================================================
class EstoqueWindow(QWidget):
    def __init__(self, parent_stack):
        super().__init__()
        self.parent_stack = parent_stack
        self.setStyleSheet("background-color: white;")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        titulo = QLabel("Controle de Estoque")
        titulo.setFont(QFont("Arial", 18, QFont.Bold))
        titulo.setStyleSheet("color: #1B5E20; padding: 10px;")
        layout.addWidget(titulo)

        linha_filtro = QHBoxLayout()
        lbl_filtro = QLabel("Filtrar por categoria:")
        lbl_filtro.setStyleSheet("color: #1B5E20; font-weight: bold;")
        linha_filtro.addWidget(lbl_filtro)

        self.combo_categoria = QComboBox()
        self.combo_categoria.addItems(["Todas"] + list(CARDAPIO.keys()))
        self.combo_categoria.setStyleSheet("""
            QComboBox {
                padding: 6px; border: 2px solid #2E7D32;
                border-radius: 6px; background-color: white;
                color: #1B5E20; font-weight: bold;
            }
            QComboBox::drop-down {
                border: none; background-color: #2E7D32;
                width: 25px;
            }
            QComboBox QAbstractItemView {
                background-color: white; color: #1B5E20;
                selection-background-color: #A5D6A7;
            }
        """)
        self.combo_categoria.currentTextChanged.connect(self.carregar)
        linha_filtro.addWidget(self.combo_categoria)
        linha_filtro.addStretch()
        layout.addLayout(linha_filtro)

        self.tabela = QTableWidget()
        self.tabela.setColumnCount(6)
        self.tabela.setHorizontalHeaderLabels(
            ["ID", "Item", "Categoria", "Preço", "Qtd", "Mínimo"]
        )
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        # Tabela: cabeçalho verde, fundo branco, SELEÇÃO VERDE
        self.tabela.setStyleSheet("""
            QTableWidget {
                background-color: white;
                border: 2px solid #2E7D32;
                border-radius: 6px;
                gridline-color: #E0E0E0;
                color: #1B5E20;
            }
            QHeaderView::section {
                background-color: #2E7D32;
                color: white;
                padding: 8px;
                font-weight: bold;
                border: none;
            }
            QTableWidget::item {
                background-color: white;
                color: #1B5E20;
            }
            QTableWidget::item:selected {
                background-color: #2E7D32;
                color: white;
            }
        """)
        layout.addWidget(self.tabela)

        legenda = QLabel(" Legenda: 🔴 Sem estoque   |   🟡 Estoque baixo   |   🟢 Estoque OK")
        legenda.setStyleSheet("color: #555; padding: 8px;")
        layout.addWidget(legenda)

        linha_btn = QHBoxLayout()

        btn_entrada = QPushButton("Entrada (+1)")
        btn_entrada.setStyleSheet("""
            QPushButton {
                background-color: #2E7D32; color: white;
                padding: 10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #1B5E20; }
        """)
        btn_entrada.clicked.connect(lambda: self.ajustar(1))

        btn_saida = QPushButton("Saída (-1)")
        btn_saida.setStyleSheet("""
            QPushButton {
                background-color: #E53935; color: white;
                padding: 10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #C62828; }
        """)
        btn_saida.clicked.connect(lambda: self.ajustar(-1))

        btn_editar = QPushButton("Editar")
        btn_editar.setStyleSheet("""
            QPushButton {
                background-color: #C62828; color: white;
                padding: 10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #B71C1C; }
        """)
        btn_editar.clicked.connect(self.editar)

        btn_repor = QPushButton("Repor todos baixos")
        btn_repor.setStyleSheet("""
            QPushButton {
                background-color: #66BB6A; color: white;
                padding: 10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #2E7D32; }
        """)
        btn_repor.clicked.connect(self.repor_baixos)

        btn_atualizar = QPushButton("Atualizar")
        btn_atualizar.setStyleSheet("""
            QPushButton {
                background-color: #EF5350; color: white;
                padding: 10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #E53935; }
        """)
        btn_atualizar.clicked.connect(self.carregar)

        btn_voltar = QPushButton("⬅ Voltar")
        btn_voltar.setStyleSheet("""
            QPushButton {
                background-color: #B71C1C; color: white;
                padding: 10px; font-weight: bold;
                border-radius: 6px; border: none;
            }
            QPushButton:hover { background-color: #7F0000; }
        """)
        btn_voltar.clicked.connect(lambda: self.parent_stack.setCurrentIndex(0))

        linha_btn.addWidget(btn_entrada)
        linha_btn.addWidget(btn_saida)
        linha_btn.addWidget(btn_editar)
        linha_btn.addWidget(btn_repor)
        linha_btn.addWidget(btn_atualizar)
        linha_btn.addWidget(btn_voltar)
        layout.addLayout(linha_btn)

        self.carregar()

    def carregar(self):
        categoria_filtro = self.combo_categoria.currentText()
        dados = listar_estoque()

        if categoria_filtro != "Todas":
            dados = [d for d in dados if d[2] == categoria_filtro]

        self.tabela.setRowCount(len(dados))
        for i, row in enumerate(dados):
            id_, nome, cat, preco, qtd, minimo = row
            valores = [str(id_), nome, cat, f"R$ {preco:.2f}",
                       str(qtd), str(minimo)]

            for j, val in enumerate(valores):
                item = QTableWidgetItem(val)
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)

                # Cores do estoque:
                # 0 unidades: vermelho
                # 1 a 5 unidades: amarelo
                # Acima de 5 unidades: branco
                if qtd <= 0:
                    item.setBackground(QColor("#E53935"))
                    item.setForeground(QColor("white"))
                elif qtd <= 5:
                    item.setBackground(QColor("#FBC02D"))
                    item.setForeground(QColor("#212121"))
                else:
                    item.setBackground(QColor("white"))
                    item.setForeground(QColor("#1B5E20"))

                self.tabela.setItem(i, j, item)

        self.tabela.resizeRowsToContents()

    def _item_selecionado(self):
        row = self.tabela.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Atenção", "Selecione um item!")
            return None
        return int(self.tabela.item(row, 0).text())

    def ajustar(self, delta):
        item_id = self._item_selecionado()
        if item_id is None:
            return
        ajustar_quantidade(item_id, delta)
        self.carregar()

    def editar(self):
        item_id = self._item_selecionado()
        if item_id is None:
            return

        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("SELECT nome, quantidade, minimo FROM estoque WHERE id=?", (item_id,))
        nome, qtd, minimo = c.fetchone()
        conn.close()

        nova_qtd, ok1 = QInputDialog.getInt(
            self, "Editar Estoque",
            f"Quantidade atual de '{nome}':", qtd, 0, 99999
        )
        if not ok1:
            return

        novo_min, ok2 = QInputDialog.getInt(
            self, "Editar Estoque",
            f"Quantidade mínima de '{nome}':", minimo, 0, 99999
        )
        if not ok2:
            return

        atualizar_estoque(item_id, nova_qtd, novo_min)
        self.carregar()

    def repor_baixos(self):
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("SELECT id, nome, quantidade, minimo FROM estoque WHERE quantidade <= minimo")
        baixos = c.fetchall()

        if not baixos:
            QMessageBox.information(self, "Estoque", "Nenhum item baixo!")
            conn.close()
            return

        for id_, nome, qtd, minimo in baixos:
            c.execute("UPDATE estoque SET quantidade=? WHERE id=?",
                      (minimo * 2, id_))
        conn.commit()
        conn.close()
        self.carregar()
        QMessageBox.information(
            self, "Reposição",
            f"{len(baixos)} itens foram repostos para 2x o mínimo."
        )

if __name__ == "__main__":
    init_db()
    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    totem = TotemWindow()
    admin = AdminWindow()

    totem.show()
    admin.show()

    sys.exit(app.exec())